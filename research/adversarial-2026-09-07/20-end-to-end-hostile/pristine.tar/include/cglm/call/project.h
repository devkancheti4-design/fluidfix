/*
 * Copyright (c), Recep Aslantas.
 *
 * MIT License (MIT), http://opensource.org/licenses/MIT
 * Full license can be found in the LICENSE file
 */

#ifndef cglmc_project_h
#define cglmc_project_h
#ifdef __cplusplus
extern "C" {
#endif

#include "../common.h"

CGLM_EXPORT
void
glmc_unprojecti(vec3 pos, mat4 invMat, vec4 vp, vec3 dest);

CGLM_EXPORT
void
glmc_unproject(vec3 pos, mat4 m, vec4 vp, vec3 dest);

CGLM_EXPORT
void
glmc_project(vec3 pos, mat4 m, vec4 vp, vec3 dest);

CGLM_EXPORT
float
glmc_project_z(vec3 pos, mat4 m);

CGLM_EXPORT
void
glmc_pickmatrix(vec2 center, vec2 size, vec4 vp, mat4 dest);

#ifdef __cplusplus
}
#endif
#endif /* cglmc_project_h */
